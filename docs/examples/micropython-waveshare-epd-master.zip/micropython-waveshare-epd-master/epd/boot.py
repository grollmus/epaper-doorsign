import machine

machine.main('main.py')
