# Pico_ePaper_Code
## waveshare electronics
![waveshare_logo.png](waveshare_logo.png)

## 中文：
微雪电子 Pico-ePaper 系列驱动代码，支持C和Python

更多资料请在官网搜索相关产品：
> https://www.waveshare.net or https://www.waveshare.net/wiki
***
## English:
Waveshrae Pico-ePaper series drivers code, Support C and Python.

For more information, please search on the official website:
> https://www.waveshare.com or https://www.waveshare.com/wiki/Main_Page